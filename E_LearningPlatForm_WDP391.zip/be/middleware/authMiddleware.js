const jwt = require("jsonwebtoken");
const User = require("../models/User");

/* =====================================
   PROTECT ROUTE (Require Login)
===================================== */
const protect = async (req, res, next) => {
  try {
    let token;

    /* ======================
       GET TOKEN FROM HEADER
    ====================== */
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith("Bearer")
    ) {
      token = req.headers.authorization.split(" ")[1];
    }

    if (!token) {
      return res.status(401).json({
        success: false,
        message: "No token provided",
      });
    }

    /* ======================
       VERIFY TOKEN
    ====================== */
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    /* ======================
       FIND USER
    ====================== */
    const user = await User.findById(decoded.id).select("-password");

    if (!user) {
      return res.status(401).json({
        success: false,
        message: "User not found",
      });
    }

    req.user = user;

    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: "Not authorized",
      error: error.message,
    });
  }
};

/* =====================================
   ADMIN GUARD
===================================== */
const requireAdmin = (req, res, next) => {
  if (!req.user || req.user.role !== "admin") {
    return res.status(403).json({
      success: false,
      message: "Admin access only",
    });
  }
  next();
};

/* =====================================
   OPTIONAL AUTH — Login not required
   If valid token exists → attach req.user
   If absent / expired → req.user = null, next()
===================================== */
const optionalAuth = async (req, res, next) => {
  try {
    let token;
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith("Bearer")
    ) {
      token = req.headers.authorization.split(" ")[1];
    }

    if (!token) {
      req.user = null;
      return next();
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select("-password");
    req.user = user || null;
    next();
  } catch {
    req.user = null;
    next();
  }
};

module.exports = { protect, optionalAuth, requireAdmin };
