import {
  BookOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined,
  DesktopOutlined,
  EditOutlined,
  HeartFilled,
  HeartOutlined,
  LockOutlined,
  MinusOutlined,
  PlayCircleOutlined,
  PlusOutlined,
  QuestionCircleOutlined,
  SafetyCertificateOutlined,
  StarFilled,
  TeamOutlined,
  UnlockOutlined,
} from "@ant-design/icons";
import {
  Button,
  Card,
  Col,
  Divider,
  message,
  Row,
  Skeleton,
  Space,
  Tag,
  Typography,
} from "antd";
import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";

import CourseReview from "../../../components/shared/CourseReview";
import CourseService from "../../../services/api/CourseService";
import PaymentService from "../../../services/api/PaymentService";
import useAuthStore from "../../../store/slices/authStore";
import useCourseStore from "../../../store/slices/courseStore";
import { ROUTES } from "../../../utils/constants";
import {
  formatDurationClock,
  formatThousands,
  pageVariants,
} from "../../../utils/helpers";

const { Title, Text, Paragraph } = Typography;

/* ─── SectionHeading ─────────────────────────────────────────────────────── */
const SectionHeading = ({ children }) => (
  <Title level={4} style={{ marginBottom: 14, marginTop: 0, fontWeight: 700 }}>
    {children}
  </Title>
);

/* ─── CurriculumAccordion ────────────────────────────────────────────────── */
const CurriculumAccordion = ({
  sections,
  isUnlocked,
  totalLessons,
  totalQuizzes,
  duration,
}) => {
  const [openKeys, setOpenKeys] = useState([]);

  const toggleAll = () => {
    setOpenKeys(
      openKeys.length === sections.length
        ? []
        : sections.map((s, i) => s._id || i),
    );
  };

  const toggle = (key) =>
    setOpenKeys((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key],
    );

  return (
    <div>
      {/* Summary row */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: 12,
        }}
      >
        <Text type="secondary" style={{ fontSize: 13 }}>
          {sections.length} sections &nbsp;·&nbsp; {totalLessons} lessons
          &nbsp;·&nbsp; Total length {duration}
        </Text>
        <Button
          type="link"
          style={{ padding: 0, fontSize: 13, color: "#f97316" }}
          onClick={toggleAll}
        >
          {openKeys.length === sections.length ? "Collapse all" : "Expand all"}
        </Button>
      </div>

      {/* Sections */}
      <div
        style={{
          border: "1px solid #e5e7eb",
          borderRadius: 8,
          overflow: "hidden",
        }}
      >
        {sections.map((sec, idx) => {
          const key = sec._id || idx;
          const isOpen = openKeys.includes(key);
          const itemCount = (sec.items ?? []).length;

          return (
            <div
              key={key}
              style={{
                borderBottom:
                  idx < sections.length - 1 ? "1px solid #e5e7eb" : "none",
              }}
            >
              {/* Header row */}
              <div
                onClick={() => toggle(key)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  padding: "12px 16px",
                  background: "#f9fafb",
                  cursor: "pointer",
                  userSelect: "none",
                  gap: 12,
                }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                    flex: 1,
                  }}
                >
                  {isOpen ? (
                    <MinusOutlined
                      style={{ color: "#f97316", fontSize: 12, flexShrink: 0 }}
                    />
                  ) : (
                    <PlusOutlined
                      style={{ color: "#f97316", fontSize: 12, flexShrink: 0 }}
                    />
                  )}
                  <Text strong style={{ fontSize: 14 }}>
                    {sec.title}
                  </Text>
                </div>
                <Text
                  type="secondary"
                  style={{ fontSize: 13, whiteSpace: "nowrap" }}
                >
                  {itemCount} {itemCount === 1 ? "lesson" : "lessons"}
                </Text>
              </div>

              {/* Items */}
              {isOpen && (
                <div>
                  {(sec.items ?? []).map((item, i) => {
                    const dur = item.itemId?.duration;
                    const isQuiz = item.itemType === "quiz";
                    return (
                      <div
                        key={item._id || i}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 10,
                          padding: "8px 16px 8px 40px",
                          borderTop: "1px solid #f3f4f6",
                          background: "#fff",
                        }}
                      >
                        {isQuiz ? (
                          <QuestionCircleOutlined
                            style={{ color: "#8B5CF6", fontSize: 13 }}
                          />
                        ) : isUnlocked ? (
                          <PlayCircleOutlined
                            style={{ color: "#10b981", fontSize: 13 }}
                          />
                        ) : (
                          <LockOutlined
                            style={{ color: "#9ca3af", fontSize: 13 }}
                          />
                        )}
                        <Text style={{ flex: 1, fontSize: 13 }}>
                          {item.title}
                        </Text>
                        {dur > 0 && (
                          <Text type="secondary" style={{ fontSize: 12 }}>
                            {formatDurationClock(dur)}
                          </Text>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* ─── CourseDetailPage ────────────────────────────────────────────────────── */
const CourseDetailPage = () => {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuthStore();
  const {
    enrolledCourseIds,
    wishlistIds,
    enroll,
    toggleWishlist,
    setEnrolledCourseIds,
  } = useCourseStore();

  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [enrollChecked, setEnrollChecked] = useState(false);
  const [paying, setPaying] = useState(false);

  useEffect(() => {
    const payment = searchParams.get("payment");
    const courseId = searchParams.get("courseId");
    if (payment === "success" && courseId) {
      message.success("Payment successful! You can start learning now.");
      enroll(courseId);
      PaymentService.getEnrolledCourseIds()
        .then(setEnrolledCourseIds)
        .catch(() => {});
      navigate(`/courses/${courseId}`, { replace: true });
    } else if (payment === "failed") {
      message.error("Payment failed. Please try again.");
      navigate(`/courses/${id}`, { replace: true });
    } else if (payment === "error") {
      message.error("An error occurred during payment.");
      navigate(`/courses/${id}`, { replace: true });
    }
  }, [searchParams]);

  useEffect(() => {
    if (!isAuthenticated) {
      setEnrollChecked(true);
      return;
    }
    PaymentService.getEnrolledCourseIds()
      .then(setEnrolledCourseIds)
      .catch(() => {})
      .finally(() => setEnrollChecked(true));
  }, [isAuthenticated, id]);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    CourseService.getCoursePreview(id)
      .then((data) => {
        if (!data) {
          message.error("Course not found");
          navigate(ROUTES.COURSES);
          return;
        }
        setCourse(data);
      })
      .catch(() => {
        message.error("Course not found");
        navigate(ROUTES.COURSES);
      })
      .finally(() => setLoading(false));
  }, [id]);

  if (loading || !enrollChecked) {
    return (
      <div style={{ maxWidth: 1160, margin: "0 auto", padding: "40px 24px" }}>
        <Skeleton active paragraph={{ rows: 10 }} />
      </div>
    );
  }

  if (!course) return null;

  const courseId = course._id?.toString();
  const instructor =
    course.instructorId?.fullname ?? course.instructorId?.email ?? "Instructor";
  const categoryName = course.category?.name ?? "";
  const isFree = course.price === 0;
  const isEnrolled = enrolledCourseIds.includes(courseId);
  const isOwner =
    !!user?._id &&
    (course.instructorId?._id?.toString() === user._id?.toString() ||
      course.instructorId?.toString() === user._id?.toString());
  const isAdmin = user?.role === "admin";
  const isUnlocked = isEnrolled || isOwner || isAdmin;
  const isWishlisted = wishlistIds.includes(courseId);

  const totalLessons = (course.sections ?? []).reduce(
    (a, s) => a + (s.items?.filter((i) => i.itemType === "lesson").length ?? 0),
    0,
  );
  const totalQuizzes = (course.sections ?? []).reduce(
    (a, s) => a + (s.items?.filter((i) => i.itemType === "quiz").length ?? 0),
    0,
  );
  const duration = formatDurationClock(course.totalDuration);
  const sections = course.sections ?? [];

  const handleBuy = async () => {
    if (!isAuthenticated) {
      navigate(ROUTES.LOGIN);
      return;
    }
    if (isFree) {
      setPaying(true);
      try {
        const res = await PaymentService.enrollFreeCourse(course._id);
        if (res?.success) {
          enroll(courseId);
          try {
            const ids = await PaymentService.getEnrolledCourseIds();
            setEnrolledCourseIds(ids);
          } catch (_) {}
          message.success("Enrolled successfully!");
          navigate(`/student/learning/${course._id}`);
        } else {
          message.error(res?.message || "Enrollment failed. Please try again.");
        }
      } catch (err) {
        const msg = err?.response?.data?.message || err?.message;
        if (err?.response?.status === 400)
          message.warning(msg || "Cannot enroll in this course");
        else if (err?.response?.status === 404)
          message.error("Course not found");
        else message.error(msg || "An error occurred while enrolling");
      } finally {
        setPaying(false);
      }
      return;
    }
    setPaying(true);
    try {
      const res = await PaymentService.createPayment(course._id, "vnpay");
      if (res?.paymentUrl) {
        window.location.href = res.paymentUrl;
      } else {
        message.error("Could not create payment. Please try again.");
      }
    } catch (err) {
      const msg = err?.response?.data?.message || err?.message;
      if (err?.response?.status === 400)
        message.warning(msg || "Cannot create payment");
      else message.error(msg || "An error occurred while creating payment");
    } finally {
      setPaying(false);
    }
  };

  const handleLearn = () => navigate(`/student/learning/${course._id}`);
  const handleWishlist = () => {
    if (!isAuthenticated) {
      navigate(ROUTES.LOGIN);
      return;
    }
    toggleWishlist(courseId);
  };

  const sidebarInfoItems = [
    { icon: <BookOutlined />, text: `Total ${totalLessons} lessons` },
    { icon: <QuestionCircleOutlined />, text: `${totalQuizzes} quizzes` },
    { icon: <ClockCircleOutlined />, text: `Duration ${duration || "—"}` },
    { icon: <DesktopOutlined />, text: "Learn anytime, anywhere" },
    { icon: <SafetyCertificateOutlined />, text: "Certificate of completion" },
  ];

  return (
    <motion.div
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <div style={{ maxWidth: 1160, margin: "0 auto", padding: "32px 24px" }}>
        {/* Breadcrumb */}
        <Space style={{ marginBottom: 20, fontSize: 13 }}>
          <Button
            type="link"
            style={{ padding: 0 }}
            onClick={() => navigate(ROUTES.COURSES)}
          >
            Courses
          </Button>
          <Text type="secondary">/</Text>
          {categoryName && (
            <>
              <Text type="secondary">{categoryName}</Text>
              <Text type="secondary">/</Text>
            </>
          )}
          <Text style={{ maxWidth: 300 }} ellipsis>
            {course.title}
          </Text>
        </Space>

        <Row gutter={[40, 32]} align="top">
          {/* ── LEFT COLUMN ────────────────────────────────────────────── */}
          <Col xs={24} lg={16}>
            <Space direction="vertical" size={36} style={{ width: "100%" }}>
              {/* ① Title + Description */}
              <div>
                <Space wrap style={{ marginBottom: 10 }}>
                  {categoryName && <Tag color="blue">{categoryName}</Tag>}
                  {course.level && <Tag>{course.level}</Tag>}
                  {isEnrolled && (
                    <Tag icon={<UnlockOutlined />} color="success">
                      Enrolled
                    </Tag>
                  )}
                  {(isOwner || isAdmin) && !isEnrolled && (
                    <Tag color="purple">{isAdmin ? "Admin" : "Instructor"}</Tag>
                  )}
                </Space>

                <Title
                  level={2}
                  style={{ marginBottom: 12, fontWeight: 800, lineHeight: 1.3 }}
                >
                  {course.title}
                </Title>

                <Paragraph
                  type="secondary"
                  style={{ fontSize: 14, lineHeight: 1.75, marginBottom: 18 }}
                >
                  {course.description || "No description available."}
                </Paragraph>

                {/* Meta row */}
                <Space wrap size="large">
                  <Space size={4}>
                    <StarFilled style={{ color: "#F59E0B" }} />
                    <Text strong>{Number(course.rating ?? 0).toFixed(1)}</Text>
                  </Space>
                  <Space size={4}>
                    <TeamOutlined style={{ color: "#6b7280" }} />
                    <Text type="secondary">
                      {course.enrollmentCount ?? 0} students
                    </Text>
                  </Space>
                  {duration && (
                    <Space size={4}>
                      <ClockCircleOutlined style={{ color: "#6b7280" }} />
                      <Text type="secondary">{duration}</Text>
                    </Space>
                  )}
                  <Space size={4}>
                    <BookOutlined style={{ color: "#6b7280" }} />
                    <Text type="secondary">
                      {totalLessons} lessons · {totalQuizzes} quizzes
                    </Text>
                  </Space>
                </Space>
              </div>

              {/* ② Course Content */}
              <div>
                <SectionHeading>Course Content</SectionHeading>
                {sections.length === 0 ? (
                  <Text type="secondary">No course content yet.</Text>
                ) : (
                  <CurriculumAccordion
                    sections={sections}
                    isUnlocked={isUnlocked}
                    totalLessons={totalLessons}
                    totalQuizzes={totalQuizzes}
                    duration={duration}
                  />
                )}
              </div>

              {/* ③ Reviews */}
              <div>
                <SectionHeading>Student Reviews</SectionHeading>
                <CourseReview
                  courseId={courseId}
                  isInstructor={isOwner || isAdmin}
                />
              </div>
            </Space>
          </Col>

          {/* ── RIGHT SIDEBAR ────────────────────────────────────────────── */}
          <Col
            xs={24}
            lg={8}
            style={{ alignSelf: "flex-start", position: "sticky", top: 24 }}
          >
            <Card
              style={{
                borderRadius: 12,
                boxShadow: "0 4px 20px rgba(0,0,0,0.09)",
                border: "1px solid #e5e7eb",
                overflow: "hidden",
              }}
              bodyStyle={{ padding: 0 }}
            >
              {/* Thumbnail with play overlay */}
              <div style={{ position: "relative" }}>
                <img
                  src={
                    course.thumbnail ||
                    "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600&h=338&fit=crop"
                  }
                  alt={course.title}
                  style={{
                    width: "100%",
                    aspectRatio: "16/9",
                    objectFit: "cover",
                    display: "block",
                  }}
                />
              </div>

              {/* Price + Buttons */}
              <div style={{ padding: "20px 20px 16px" }}>
                {isEnrolled ? (
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 8,
                      padding: "8px 12px",
                      background: "#d1fae5",
                      borderRadius: 8,
                      marginBottom: 12,
                    }}
                  >
                    <CheckCircleOutlined style={{ color: "#059669" }} />
                    <Text strong style={{ color: "#065f46", fontSize: 13 }}>
                      You are enrolled
                    </Text>
                  </div>
                ) : (
                  <div style={{ marginBottom: 14 }}>
                    <Title
                      level={2}
                      className="gradient-text"
                      style={{
                        margin: 0,
                        lineHeight: 1,
                        display: "inline-block",
                      }}
                    >
                      {isFree ? "Free" : formatThousands(course.price)}
                    </Title>
                    {!isFree && (
                      <Text
                        delete
                        type="secondary"
                        style={{ marginLeft: 10, fontSize: 13 }}
                      >
                        {formatThousands(Math.round(course.price * 1.4))}
                      </Text>
                    )}
                  </div>
                )}

                {/* Primary CTA */}
                {isEnrolled ? (
                  <Button
                    type="primary"
                    size="large"
                    block
                    icon={<PlayCircleOutlined />}
                    onClick={handleLearn}
                    style={{
                      borderRadius: 8,
                      height: 44,
                      fontWeight: 700,
                      fontSize: 15,
                      background: "linear-gradient(135deg,#10b981,#059669)",
                      border: "none",
                    }}
                  >
                    Start Learning
                  </Button>
                ) : (
                  <Button
                    type="primary"
                    size="large"
                    block
                    loading={paying}
                    onClick={handleBuy}
                    className="btn-aurora"
                    style={{
                      borderRadius: 8,
                      height: 44,
                      fontWeight: 700,
                      fontSize: 15,
                      border: "none",
                    }}
                  >
                    {isFree ? "Enroll for Free" : "Buy Now"}
                  </Button>
                )}

                {/* Wishlist */}
                {!isEnrolled && (
                  <Button
                    block
                    size="middle"
                    style={{ marginTop: 8, borderRadius: 8 }}
                    icon={
                      isWishlisted ? (
                        <HeartFilled style={{ color: "#ef4444" }} />
                      ) : (
                        <HeartOutlined />
                      )
                    }
                    onClick={handleWishlist}
                  >
                    {isWishlisted ? "Saved" : "Save Course"}
                  </Button>
                )}

                {/* Owner/Admin edit */}
                {(isOwner || isAdmin) && (
                  <Button
                    block
                    size="middle"
                    icon={<EditOutlined />}
                    style={{ marginTop: 8, borderRadius: 8 }}
                    onClick={() =>
                      navigate(`/instructor/courses/edit/${course._id}`)
                    }
                  >
                    {isAdmin ? "Manage Course" : "Edit Course"}
                  </Button>
                )}
              </div>

              <Divider style={{ margin: 0 }} />

              {/* Course info */}
              <div style={{ padding: "14px 20px 18px" }}>
                {sidebarInfoItems.map((item) => (
                  <div
                    key={item.text}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 10,
                      padding: "5px 0",
                    }}
                  >
                    <span style={{ color: "#6b7280", fontSize: 15 }}>
                      {item.icon}
                    </span>
                    <Text style={{ fontSize: 13 }}>{item.text}</Text>
                  </div>
                ))}
              </div>
            </Card>
          </Col>
        </Row>
      </div>
    </motion.div>
  );
};

export default CourseDetailPage;
